/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package loginguifrommemory;

/**
 *
 * @author eliza
 * Self-practice program
 */
public class LoginGUIFromMemory {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // FIRST STEP:
        // create one form object for form to exist within main (with same name as the form class' name.)
        // b/c main is the stage and things can only act here.
        LoginForm l = new LoginForm();
            /*
            TIP:
            if an error/lightbulb occurs here, likely b/c this java file is 
            not in the same folder as the other java class file it is creating an object for 
            
        
        SECOND STEP:
        Set the form object to be visible,
        so the panel window opens up and can actually be seen on the screen and interacted with.
        true/false argument
        */
        l.setVisible(true);
    }
    
}
