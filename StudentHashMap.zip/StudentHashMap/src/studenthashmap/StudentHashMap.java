/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studenthashmap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

/**
 *
 * @author eliza
 */
public class StudentHashMap {
    
    // is a global variable so we don't need to keep remaking Scanner variable in other methods
    static Scanner keyboard = new Scanner(System.in);
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // HashMap for the students and their courses
        // Student number (id) is the key
        HashMap<Integer, ArrayList<String>> students = new HashMap<Integer, ArrayList<String>>();
    
        // variables
        int studentNumber;      // id for each string course in the entry content/file
        String courseNumber, repeat = "", entry;
        
        do
        {
            // get the inputs of the courses
            entry = getEntry();
            
            // create an array to allow storage of the student id and course number
            // they are gonna go into separate indexes of the array
            String entries[] = entry.split(" ");    // splits the entry by a space
                                                    // puts the student id into index 0
                                                    // puts the course number into index i

            studentNumber = Integer.parseInt(entries[0]);
            courseNumber = entries[1];

            // build the HashMap

            if(students.containsKey(studentNumber))
            {
                // check to see if the id is a key that is already in the HashMap
                // set the ArrayList associated with the key,
                ArrayList<String> courses = students.get(studentNumber);
                // then add the course to the ArrayList
                courses.add(entries[1]);
                // then update the HashMap using the .replace() method
                students.replace(studentNumber, courses);
            }
            else
            {
                // check to see if the id is not a key that exists in the HashMap
                // make a new ArrayList
                ArrayList<String> courses = new ArrayList<String>();
                // add the course to the ArrayList
                courses.add(entries[1]);
                // use /put() method to add the student id and the course ArrayList to the Hashmap
                students.put(studentNumber, courses);
            }
            
            
            
            // ask the user to enter another course
            repeat = repeatEntry();
        } while (repeat.equalsIgnoreCase("Yes") || repeat.equalsIgnoreCase("y"));
        
        // display the contenrs of the HashMap
        System.out.println("\n");
        System.out.println(students);
    }
    
    //  method gets the value of repeat

    public static String repeatEntry()
    {
        String repeat;
        System.out.print("\nEnter Y or Yes to Continue, Enter N or No to stop: ");
        repeat = keyboard.nextLine();

        while(!repeat.equalsIgnoreCase("yes") && !repeat.equalsIgnoreCase("y") &&
                !repeat.equalsIgnoreCase("no") && !repeat.equalsIgnoreCase("n"))
        {
            System.out.println("\n\nERROR: Invalid choice entered. Try again.\n\n");
            System.out.print("Enter Y or Yes to Continue, Enter N or No to stop: ");
            repeat = keyboard.nextLine();
        }

        return repeat;
    }
    
    // method that validates the entry of a student id and a course
    public static String getEntry()
    {
        String entry;   // local variable to hold the entry
        
        // get the input of the student id and the course number
        System.out.print("Enter a student number and a course number separated by a space: \n");
        System.out.print("\nExample: 1 CS100 \nExample: 2 MATH210 \n\n");
        System.out.print("Your entry: ");
        entry = keyboard.nextLine();        
        
        // create an array to allow storage of the student id and course number
        // they are gonna go into separate indexes of the array
        String entries[] = entry.split(" ");    // splits the entry by a space
                                                // puts the student id into index 0
                                                // puts the course number into index i
        
        // input validation/error checking
        while(entries.length !=2)   // entry length needs to be min. 2
        {
            System.out.println("\n\nERROR: Invalid student number and course entered. Try again.\n\n");
            System.out.print("Enter a student number and a course number separated by a space: \n");
            System.out.print("\nExample: 1 CS100 \nExample: 2 MATH210 \n\n");
            System.out.print("Your entry: ");
            entry = keyboard.nextLine();
            entries = entry.split(" ");
        }
        
        while(isNumeric(entries[0]) == false)
        {
            System.out.println("\n\nERROR: Invalid student number entered. Try again.\n\n");
            System.out.print("Enter a student number and a course number separated by a space: \n");
            System.out.print("\nExample: 1 CS100 \nExample: 2 MATH210 \n\n");
            System.out.print("Your entry: ");
            entry = keyboard.nextLine();
            entries = entry.split(" ");
        }
        
        return entry;
    }
    
    public static boolean isNumeric(String strNum)
    {
        if (strNum == null) {
            return false;
        }
        try {
            int d = Integer.parseInt(strNum);            
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }
}
